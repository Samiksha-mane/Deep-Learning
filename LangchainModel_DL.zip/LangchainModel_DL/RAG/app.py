import streamlit as st
from rag import RAGVectorStore
from chains import RAGChain

st.set_page_config(page_title="RAG Assistant", layout="wide")

st.title("🤖 LangChain RAG Assistant")

# Initialize
@st.cache_resource
def load_chain():
    vs = RAGVectorStore()
    retriever = vs.get_retriever()
    return RAGChain(retriever)

rag = load_chain()

# UI
query = st.text_input("Ask your question:")

if query:
    with st.spinner("Thinking..."):
        answer = rag.ask(query)
        st.success(answer)