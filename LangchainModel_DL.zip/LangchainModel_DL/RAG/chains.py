import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough

load_dotenv()

class RAGChain:
    def __init__(self, retriever):
        self.retriever = retriever
        self.llm = ChatGroq(
            api_key=os.getenv("GROQ_API_KEY"),
            model="llama-3.1-8b-instant",
            temperature=0.3
        )
        self.chain = self._create_chain()

    def _create_chain(self):
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a strict assistant.

Rules:
1. Answer ONLY from context
2. If not found, say "I don't know"
3. Be concise

Context:
{context}
"""),
            ("human", "Question: {question}")
        ])

        def format_docs(docs):
            return "\n\n".join(doc.page_content for doc in docs)

        return (
            {"context": self.retriever | format_docs, "question": RunnablePassthrough()}
            | prompt
            | self.llm
            | StrOutputParser()
        )

    def ask(self, question: str):
        return self.chain.invoke(question)